package com;

public class Product {
	

	private int productId;
	private String productName;
	private int productPrice;
	private int qoh;
	public Product() {
		// TODO Auto-generated constructor stub
	}
	public int getproductId() {
		return productId;
	}
	public void setproductId(int productId) {
		this.productId = productId;
	}
	public String getproductName() {
		return productName;
	}
	public void setproductName(String productName) {
		this.productName = productName;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	public int getqoh() {
		return qoh;
	}
	public void setqoh(int qoh) {
		qoh = qoh;
	}
	public Product(int productId, String productName, int productPrice, int qoh) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		qoh = qoh;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", qoh=" + qoh + "]";
	}
	

}
