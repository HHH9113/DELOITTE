package com.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.Product;
import com.dao.ProductDAO;

public class ProductDAOImpl implements ProductDAO {
	
	
	Configuration configuration =null;
	SessionFactory factory=null;
	public ProductDAOImpl() {
		configuration = new Configuration().configure();
		factory = configuration.buildSessionFactory();	// TODO Auto-generated constructor stub
	}
	

	@Override
	public boolean addProduct(Product product) {
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(product);
		transaction.commit();
		return false;
		
	}

	@Override
	public List<Product> listProducts() {
		Session session = factory.openSession();
		Query query =session.createQuery("from Product");
		return query.list();
		
	}

}
