package com.dao;

import java.util.List;

import com.Product;

public interface ProductDAO {
	
	public boolean addProduct(Product product);
	public List<Product> listProducts();

}
